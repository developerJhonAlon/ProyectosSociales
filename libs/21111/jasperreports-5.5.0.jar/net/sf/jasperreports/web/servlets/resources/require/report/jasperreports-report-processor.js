define(["jquery-1.10.2"], function($) {

    return {
        processReport: function(reportInstance) {
            // do something with reportInstance
        }
    };
});
